==========================================================================
          ePOS-Print SDK for Windows Store apps  Version 1.9.0a

          Copyright Seiko Epson Corporation 2014-2015 All rights reserved.
==========================================================================

1. About this software

The ePOS-Print SDK for Windows Store apps is a SDK aimed at development 
engineers who are developing Windows Store apps for printing on an 
EPSON TM printer.
Applications are developed using the APIs provided by ePOS-Print SDK.
For detailed information, please see ePOS-Print SDK for Windows Store apps
User's Manual.

Windows Versions
  Windows8.1 x86
  Windows8.1 x64

Supported Printers
  EPSON TM-T88V
  EPSON TM-T70
  EPSON TM-T70II
  EPSON TM-T20
  EPSON TM-T82
  EPSON TM-T81II
  EPSON TM-T82II
  EPSON TM-U220 series
  EPSON TM-P60
  EPSON TM-P60II
  EPSON TM-T90II
  EPSON TM-T20II
  EPSON TM-P80
  EPSON TM-U330 series
  EPSON TM-P20
  EPSON TM-m10

Supported Interfaces
  Wired LAN
  Wireless LAN
  Bluetooth


2. Supplied Files

- LibEposPrint.vsix
  The ePOS-Print library of installer-style.
- ePOS-Print_Sample_WinStoreApps.zip
  A sample program file.
- EULA.en.txt
  Contains the SOFTWARE LICENSE AGREEMENT.
- EULA.jp.txt
  Contains the SOFTWARE LICENSE AGREEMENT. (The Japanese-language edition)
- ePOS-Print_SDK_WinStoreApps_en_revE.pdf
  A user's manual.
- ePOS-Print_SDK_WinStoreApps_ja_revD.pdf
  A user's manual. (The Japanese-language edition)
- ePOS-Print_SDK_WinStoreApps_AppDevGuide_EN_RevA.pdf
  A developer's guide
- ePOS-Print_SDK_WinStoreApps_AppDevGuide_JA_RevA.pdf
  A developer's guide (The Japanese-language edition)
- README.en.txt
  This file.
- README.jp.txt
  The Japanese-language edition of this file.

3. Remarks

- For detailed information, please see ePOS-Print SDK for Windows Store apps User's Manual.

4. Modification from the old version
  
  Version 1.9.0a
    - Bug Fixed.
      - In ePOSReceiptPrintSample, when the TM-T88V is to print on the paper of the paper width 58mm,
        a new line enters the middle of a line.
  
  Version 1.9.0
    - Added the BeginTransactionAsync API for beginning transaction.
    - Added the EndTransactionAsync API for ending transaction.
    - Added the GetStatusAsync API for getting the printer status.
    - Added the support printers.
      - TM-m10
      - TM-P80 Autocutter model
    - Bug Fixed.
      - In the sample program, it can not be created store application package.
      - In Visual Studio 2015, VisualBasic version of the sample program can not build.

  Version 1.7.1
    - Bug Fixed.
      - Under Bluetooth connection, the openPrinter method may fail if application calls it immediately
        after the closePrinter method.

  Version 1.7.0
    - Added the support languages.
      - Indian

  Version 1.6.0
    - Added the support printers.
      - TM-P20
    - Added an printer search API for getting the device name.
    - Added the OpenPrinterAsync API for timeout settings.
    - Improved the OpenPrinterAsync API.
      - Not only IP address also MAC address or the host name can be set to the deviceName.
        (Only TCP/IP connection)
    - Improved the log function.
      - Compression of the backup file.
      - Improved the output content.
    - Specification change.
      - openPrinter returns an error after specified time passed if the target
        printer is already opened. (Only TCP/IP connection)

  Version 1.5.0
    - Added the support printers.
      - TM-U330
    - Added an API for compression image data processing.

  Version 1.4.2
    - New release.
